﻿namespace Calculo_Nómina
{
    partial class frm9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpResultadosFinales = new System.Windows.Forms.GroupBox();
            this.btn_Salir_ResultadoFinal = new System.Windows.Forms.Button();
            this.txtSalarioNetoResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_SalarioNetoResultadoFinal = new System.Windows.Forms.Label();
            this.txtImpuestoRentaResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_ImpuestoRentaResultadoFinal = new System.Windows.Forms.Label();
            this.txtTrabajadorBPResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_TrabajadorBPResultadoFinal = new System.Windows.Forms.Label();
            this.txtAsociaciónResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_AsociaciónResultadoFinal = new System.Windows.Forms.Label();
            this.txtMontoBonoResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_MontoBonoResultadoFinal = new System.Windows.Forms.Label();
            this.txtSalarioBrutoResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_SalarioBrutoResultadoFinal = new System.Windows.Forms.Label();
            this.txtNombreResultadoFinal = new System.Windows.Forms.TextBox();
            this.lbl_NombreResultadoFinal = new System.Windows.Forms.Label();
            this.lbl_EnferdadMaternidad = new System.Windows.Forms.Label();
            this.lbl_InvalidezMuerte = new System.Windows.Forms.Label();
            this.txt_EnfermedadMaternidad = new System.Windows.Forms.TextBox();
            this.txt_InvalidezMuerte = new System.Windows.Forms.TextBox();
            this.grpResultadosFinales.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpResultadosFinales
            // 
            this.grpResultadosFinales.BackColor = System.Drawing.SystemColors.MenuBar;
            this.grpResultadosFinales.Controls.Add(this.txt_InvalidezMuerte);
            this.grpResultadosFinales.Controls.Add(this.txt_EnfermedadMaternidad);
            this.grpResultadosFinales.Controls.Add(this.lbl_InvalidezMuerte);
            this.grpResultadosFinales.Controls.Add(this.lbl_EnferdadMaternidad);
            this.grpResultadosFinales.Controls.Add(this.btn_Salir_ResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtSalarioNetoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_SalarioNetoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtImpuestoRentaResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_ImpuestoRentaResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtTrabajadorBPResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_TrabajadorBPResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtAsociaciónResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_AsociaciónResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtMontoBonoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_MontoBonoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtSalarioBrutoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_SalarioBrutoResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.txtNombreResultadoFinal);
            this.grpResultadosFinales.Controls.Add(this.lbl_NombreResultadoFinal);
            this.grpResultadosFinales.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpResultadosFinales.Location = new System.Drawing.Point(24, 12);
            this.grpResultadosFinales.Name = "grpResultadosFinales";
            this.grpResultadosFinales.Size = new System.Drawing.Size(642, 384);
            this.grpResultadosFinales.TabIndex = 4;
            this.grpResultadosFinales.TabStop = false;
            this.grpResultadosFinales.Text = "Resultado";
            // 
            // btn_Salir_ResultadoFinal
            // 
            this.btn_Salir_ResultadoFinal.Location = new System.Drawing.Point(10, 350);
            this.btn_Salir_ResultadoFinal.Name = "btn_Salir_ResultadoFinal";
            this.btn_Salir_ResultadoFinal.Size = new System.Drawing.Size(101, 28);
            this.btn_Salir_ResultadoFinal.TabIndex = 17;
            this.btn_Salir_ResultadoFinal.Text = "Salir";
            this.btn_Salir_ResultadoFinal.UseVisualStyleBackColor = true;
            this.btn_Salir_ResultadoFinal.Click += new System.EventHandler(this.btn_Salir_ResultadoFinal_Click);
            // 
            // txtSalarioNetoResultadoFinal
            // 
            this.txtSalarioNetoResultadoFinal.Enabled = false;
            this.txtSalarioNetoResultadoFinal.Location = new System.Drawing.Point(457, 80);
            this.txtSalarioNetoResultadoFinal.Name = "txtSalarioNetoResultadoFinal";
            this.txtSalarioNetoResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtSalarioNetoResultadoFinal.TabIndex = 13;
            // 
            // lbl_SalarioNetoResultadoFinal
            // 
            this.lbl_SalarioNetoResultadoFinal.AutoSize = true;
            this.lbl_SalarioNetoResultadoFinal.Location = new System.Drawing.Point(335, 83);
            this.lbl_SalarioNetoResultadoFinal.Name = "lbl_SalarioNetoResultadoFinal";
            this.lbl_SalarioNetoResultadoFinal.Size = new System.Drawing.Size(116, 20);
            this.lbl_SalarioNetoResultadoFinal.TabIndex = 12;
            this.lbl_SalarioNetoResultadoFinal.Text = "Salario neto:";
            // 
            // txtImpuestoRentaResultadoFinal
            // 
            this.txtImpuestoRentaResultadoFinal.Enabled = false;
            this.txtImpuestoRentaResultadoFinal.Location = new System.Drawing.Point(456, 312);
            this.txtImpuestoRentaResultadoFinal.Name = "txtImpuestoRentaResultadoFinal";
            this.txtImpuestoRentaResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtImpuestoRentaResultadoFinal.TabIndex = 11;
            // 
            // lbl_ImpuestoRentaResultadoFinal
            // 
            this.lbl_ImpuestoRentaResultadoFinal.AutoSize = true;
            this.lbl_ImpuestoRentaResultadoFinal.Location = new System.Drawing.Point(170, 312);
            this.lbl_ImpuestoRentaResultadoFinal.Name = "lbl_ImpuestoRentaResultadoFinal";
            this.lbl_ImpuestoRentaResultadoFinal.Size = new System.Drawing.Size(260, 20);
            this.lbl_ImpuestoRentaResultadoFinal.TabIndex = 10;
            this.lbl_ImpuestoRentaResultadoFinal.Text = "Monto del impuesto de Renta:";
            // 
            // txtTrabajadorBPResultadoFinal
            // 
            this.txtTrabajadorBPResultadoFinal.Enabled = false;
            this.txtTrabajadorBPResultadoFinal.Location = new System.Drawing.Point(456, 279);
            this.txtTrabajadorBPResultadoFinal.Name = "txtTrabajadorBPResultadoFinal";
            this.txtTrabajadorBPResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtTrabajadorBPResultadoFinal.TabIndex = 9;
            // 
            // lbl_TrabajadorBPResultadoFinal
            // 
            this.lbl_TrabajadorBPResultadoFinal.AutoSize = true;
            this.lbl_TrabajadorBPResultadoFinal.Location = new System.Drawing.Point(52, 279);
            this.lbl_TrabajadorBPResultadoFinal.Name = "lbl_TrabajadorBPResultadoFinal";
            this.lbl_TrabajadorBPResultadoFinal.Size = new System.Drawing.Size(378, 20);
            this.lbl_TrabajadorBPResultadoFinal.TabIndex = 8;
            this.lbl_TrabajadorBPResultadoFinal.Text = "Monto de Aporte Trabajador Banco Popular:";
            // 
            // txtAsociaciónResultadoFinal
            // 
            this.txtAsociaciónResultadoFinal.Enabled = false;
            this.txtAsociaciónResultadoFinal.Location = new System.Drawing.Point(456, 246);
            this.txtAsociaciónResultadoFinal.Name = "txtAsociaciónResultadoFinal";
            this.txtAsociaciónResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtAsociaciónResultadoFinal.TabIndex = 7;
            // 
            // lbl_AsociaciónResultadoFinal
            // 
            this.lbl_AsociaciónResultadoFinal.AutoSize = true;
            this.lbl_AsociaciónResultadoFinal.Location = new System.Drawing.Point(144, 246);
            this.lbl_AsociaciónResultadoFinal.Name = "lbl_AsociaciónResultadoFinal";
            this.lbl_AsociaciónResultadoFinal.Size = new System.Drawing.Size(286, 20);
            this.lbl_AsociaciónResultadoFinal.TabIndex = 6;
            this.lbl_AsociaciónResultadoFinal.Text = "Monto de Asociación Solidarista:";
            // 
            // txtMontoBonoResultadoFinal
            // 
            this.txtMontoBonoResultadoFinal.Enabled = false;
            this.txtMontoBonoResultadoFinal.Location = new System.Drawing.Point(162, 125);
            this.txtMontoBonoResultadoFinal.Name = "txtMontoBonoResultadoFinal";
            this.txtMontoBonoResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtMontoBonoResultadoFinal.TabIndex = 5;
            // 
            // lbl_MontoBonoResultadoFinal
            // 
            this.lbl_MontoBonoResultadoFinal.AutoSize = true;
            this.lbl_MontoBonoResultadoFinal.Location = new System.Drawing.Point(6, 128);
            this.lbl_MontoBonoResultadoFinal.Name = "lbl_MontoBonoResultadoFinal";
            this.lbl_MontoBonoResultadoFinal.Size = new System.Drawing.Size(146, 20);
            this.lbl_MontoBonoResultadoFinal.TabIndex = 4;
            this.lbl_MontoBonoResultadoFinal.Text = "Monto del Bono:";
            // 
            // txtSalarioBrutoResultadoFinal
            // 
            this.txtSalarioBrutoResultadoFinal.Enabled = false;
            this.txtSalarioBrutoResultadoFinal.Location = new System.Drawing.Point(162, 80);
            this.txtSalarioBrutoResultadoFinal.Name = "txtSalarioBrutoResultadoFinal";
            this.txtSalarioBrutoResultadoFinal.Size = new System.Drawing.Size(145, 27);
            this.txtSalarioBrutoResultadoFinal.TabIndex = 3;
            // 
            // lbl_SalarioBrutoResultadoFinal
            // 
            this.lbl_SalarioBrutoResultadoFinal.AutoSize = true;
            this.lbl_SalarioBrutoResultadoFinal.Location = new System.Drawing.Point(29, 83);
            this.lbl_SalarioBrutoResultadoFinal.Name = "lbl_SalarioBrutoResultadoFinal";
            this.lbl_SalarioBrutoResultadoFinal.Size = new System.Drawing.Size(123, 20);
            this.lbl_SalarioBrutoResultadoFinal.TabIndex = 2;
            this.lbl_SalarioBrutoResultadoFinal.Text = "Salario bruto:";
            // 
            // txtNombreResultadoFinal
            // 
            this.txtNombreResultadoFinal.Enabled = false;
            this.txtNombreResultadoFinal.Location = new System.Drawing.Point(162, 43);
            this.txtNombreResultadoFinal.Name = "txtNombreResultadoFinal";
            this.txtNombreResultadoFinal.Size = new System.Drawing.Size(305, 27);
            this.txtNombreResultadoFinal.TabIndex = 1;
            // 
            // lbl_NombreResultadoFinal
            // 
            this.lbl_NombreResultadoFinal.AutoSize = true;
            this.lbl_NombreResultadoFinal.Location = new System.Drawing.Point(78, 43);
            this.lbl_NombreResultadoFinal.Name = "lbl_NombreResultadoFinal";
            this.lbl_NombreResultadoFinal.Size = new System.Drawing.Size(74, 20);
            this.lbl_NombreResultadoFinal.TabIndex = 0;
            this.lbl_NombreResultadoFinal.Text = "Nombre";
            // 
            // lbl_EnferdadMaternidad
            // 
            this.lbl_EnferdadMaternidad.AutoSize = true;
            this.lbl_EnferdadMaternidad.Location = new System.Drawing.Point(195, 176);
            this.lbl_EnferdadMaternidad.Name = "lbl_EnferdadMaternidad";
            this.lbl_EnferdadMaternidad.Size = new System.Drawing.Size(235, 20);
            this.lbl_EnferdadMaternidad.TabIndex = 18;
            this.lbl_EnferdadMaternidad.Text = " Enfermedad y maternidad:";
            // 
            // lbl_InvalidezMuerte
            // 
            this.lbl_InvalidezMuerte.AutoSize = true;
            this.lbl_InvalidezMuerte.Location = new System.Drawing.Point(262, 210);
            this.lbl_InvalidezMuerte.Name = "lbl_InvalidezMuerte";
            this.lbl_InvalidezMuerte.Size = new System.Drawing.Size(168, 20);
            this.lbl_InvalidezMuerte.TabIndex = 19;
            this.lbl_InvalidezMuerte.Text = "Invalidez y Muerte:";
            // 
            // txt_EnfermedadMaternidad
            // 
            this.txt_EnfermedadMaternidad.Enabled = false;
            this.txt_EnfermedadMaternidad.Location = new System.Drawing.Point(456, 176);
            this.txt_EnfermedadMaternidad.Name = "txt_EnfermedadMaternidad";
            this.txt_EnfermedadMaternidad.Size = new System.Drawing.Size(145, 27);
            this.txt_EnfermedadMaternidad.TabIndex = 20;
            // 
            // txt_InvalidezMuerte
            // 
            this.txt_InvalidezMuerte.Enabled = false;
            this.txt_InvalidezMuerte.Location = new System.Drawing.Point(456, 213);
            this.txt_InvalidezMuerte.Name = "txt_InvalidezMuerte";
            this.txt_InvalidezMuerte.Size = new System.Drawing.Size(146, 27);
            this.txt_InvalidezMuerte.TabIndex = 21;
            // 
            // frm9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(699, 425);
            this.ControlBox = false;
            this.Controls.Add(this.grpResultadosFinales);
            this.Name = "frm9";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resultado final";
            this.grpResultadosFinales.ResumeLayout(false);
            this.grpResultadosFinales.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpResultadosFinales;
        private System.Windows.Forms.TextBox txtTrabajadorBPResultadoFinal;
        private System.Windows.Forms.Label lbl_TrabajadorBPResultadoFinal;
        private System.Windows.Forms.TextBox txtAsociaciónResultadoFinal;
        private System.Windows.Forms.Label lbl_AsociaciónResultadoFinal;
        private System.Windows.Forms.TextBox txtMontoBonoResultadoFinal;
        private System.Windows.Forms.Label lbl_MontoBonoResultadoFinal;
        private System.Windows.Forms.TextBox txtSalarioBrutoResultadoFinal;
        private System.Windows.Forms.Label lbl_SalarioBrutoResultadoFinal;
        private System.Windows.Forms.TextBox txtNombreResultadoFinal;
        private System.Windows.Forms.Label lbl_NombreResultadoFinal;
        private System.Windows.Forms.TextBox txtSalarioNetoResultadoFinal;
        private System.Windows.Forms.Label lbl_SalarioNetoResultadoFinal;
        private System.Windows.Forms.TextBox txtImpuestoRentaResultadoFinal;
        private System.Windows.Forms.Label lbl_ImpuestoRentaResultadoFinal;
        private System.Windows.Forms.Button btn_Salir_ResultadoFinal;
        private System.Windows.Forms.TextBox txt_InvalidezMuerte;
        private System.Windows.Forms.TextBox txt_EnfermedadMaternidad;
        private System.Windows.Forms.Label lbl_InvalidezMuerte;
        private System.Windows.Forms.Label lbl_EnferdadMaternidad;
    }
}